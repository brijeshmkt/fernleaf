<?php
/*
  Template Name: Hotel detail Page
 */
?>
<link rel='stylesheet' id='pkt-style-css'  href='http://fernleaf.coderadobe.com/wp-content/themes/fernleaf/style.css?ver=4.2.7' type='text/css' media='all' />
<link rel='stylesheet' id='pkt-foundation-css'  href='http://fernleaf.coderadobe.com/wp-content/themes/fernleaf/stylesheet/foundation-responsive.css?ver=4.2.7' type='text/css' media='all' />
<link rel='stylesheet' id='style-custom-css'  href='http://fernleaf.coderadobe.com/wp-content/themes/fernleaf/style-custom.css?ver=4.2.7' type='text/css' media='all' />
<link rel='stylesheet' id='Google-Font-Droid+Serif-css'  href='http://fonts.googleapis.com/css?family=Droid+Serif%3An%2Ci%2Cb%2Cbi&#038;subset=latin&#038;ver=4.2.7' type='text/css' media='all' />
<link rel='stylesheet' id='Google-Font-Open+Sans-css'  href='http://fonts.googleapis.com/css?family=Open+Sans%3An%2Ci%2Cb%2Cbi&#038;subset=latin&#038;ver=4.2.7' type='text/css' media='all' />
<link rel='stylesheet' id='Google-Font-Roboto-css'  href='http://fonts.googleapis.com/css?family=Roboto%3An%2Ci%2Cb%2Cbi&#038;subset=latin&#038;ver=4.2.7' type='text/css' media='all' />
<link rel='stylesheet' id='wtwp-font-awesome-css'  href='https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css?ver=2.2.3' type='text/css' media='all' />
<link rel='stylesheet' id='testimonials-sp-css'  href='http://fernleaf.coderadobe.com/wp-content/plugins/wp-testimonial-with-widget/assets/css/testimonials-style.css?ver=2.2.3' type='text/css' media='all' />
<link rel='stylesheet' id='testimonials_slick_style-css'  href='http://fernleaf.coderadobe.com/wp-content/plugins/wp-testimonial-with-widget/assets/css/slick.css?ver=2.2.3' type='text/css' media='all' />
<link rel='stylesheet' id='msl-main-css'  href='http://fernleaf.coderadobe.com/wp-content/plugins/master-slider/public/assets/css/masterslider.main.css?ver=2.7.1' type='text/css' media='all' />
<link rel='stylesheet' id='msl-custom-css'  href='http://fernleaf.coderadobe.com/wp-content/uploads/master-slider/custom.css?ver=2' type='text/css' media='all' />
<link rel='stylesheet' id='superfish-css'  href='http://fernleaf.coderadobe.com/wp-content/themes/fernleaf/stylesheet/superfish.css?ver=4.2.7' type='text/css' media='all' />
<link rel='stylesheet' id='fancybox-css'  href='http://fernleaf.coderadobe.com/wp-content/themes/fernleaf/stylesheet/fancybox.css?ver=4.2.7' type='text/css' media='all' />
<link rel='stylesheet' id='fancybox-thumbs-css'  href='http://fernleaf.coderadobe.com/wp-content/themes/fernleaf/stylesheet/jquery.fancybox-thumbs.css?ver=4.2.7' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-css'  href='http://fernleaf.coderadobe.com/wp-content/themes/fernleaf/stylesheet/font-awesome/font-awesome.css?ver=4.2.7' type='text/css' media='all' />
<link rel='stylesheet' id='pkt-foundation-css'  href='http://fernleaf.coderadobe.com/wp-content/themes/fernleaf/stylesheet/responsive.css' type='text/css' media='all' />
<script type='text/javascript' src='http://fernleaf.coderadobe.com/wp-includes/js/jquery/jquery.js?ver=1.11.2'></script>
<script type='text/javascript' src='http://fernleaf.coderadobe.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.2.1'></script>
<script type='text/javascript' src='http://fernleaf.coderadobe.com/wp-content/plugins/wp-testimonial-with-widget/assets/js/slick.min.js?ver=2.2.3'></script>
<script type='text/javascript' src='http://fernleaf.coderadobe.com/wp-content/themes/fernleaf/javascript/fle-custom.js?ver=4.2.7'></script>
<script type='text/javascript' src='http://fernleaf.coderadobe.com/wp-content/themes/fernleaf/javascript/jquery.fitvids.js?ver=1.0'></script>
<?php //get_header(); ?>
<div class="main-content-container">
    <div class="row">
        <div class="twelve columns">
            
        </div>
    </div>
</div>

<div class="clear"></div>
<?php 
	/*echo '<pre>';
		print_r($xml->AT_HotelList->Hotel);
	echo '</pre>';*/
?>
<script type='text/javascript' src='http://fernleaf.coderadobe.com/wp-content/themes/fernleaf/javascript/superfish.js?ver=1.0'></script>
<script type='text/javascript' src='http://fernleaf.coderadobe.com/wp-content/themes/fernleaf/javascript/supersub.js?ver=1.0'></script>
<script type='text/javascript' src='http://fernleaf.coderadobe.com/wp-content/themes/fernleaf/javascript/hoverIntent.js?ver=1.0'></script>
<script type='text/javascript' src='http://fernleaf.coderadobe.com/wp-content/themes/fernleaf/javascript/jquery.easing.js?ver=1.0'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var ATTR = {"enable":"enable","width":"80","height":"45"};
/* ]]> */
</script>
<script type='text/javascript' src='http://fernleaf.coderadobe.com/wp-content/themes/fernleaf/javascript/jquery.fancybox.js?ver=1.0'></script>
<script type='text/javascript' src='http://fernleaf.coderadobe.com/wp-content/themes/fernleaf/javascript/jquery.fancybox-media.js?ver=1.0'></script>
<script type='text/javascript' src='http://fernleaf.coderadobe.com/wp-content/themes/fernleaf/javascript/jquery.fancybox-thumbs.js?ver=1.0'></script>
<script type='text/javascript' src='http://fernleaf.coderadobe.com/wp-content/themes/fernleaf/javascript/gdl-scripts.js?ver=1.0'></script>
<script type='text/javascript' src='http://fernleaf.coderadobe.com/wp-includes/js/comment-reply.min.js?ver=4.2.7'></script>
<?php //get_footer(); ?>
