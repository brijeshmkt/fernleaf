<?php
/*
Template Name: Page result Page
*/
?>

<?php

	print_r($_GET);


    $client  = new SoapClient('http://ws.asiatravel.net/HotelB2BAPI/atHotelsService.asmx?wsdl');
    $header = new SoapHeader(
    'http://instantroom.com/',
    'SOAPHeaderAuthentication',
    array(
        'UserName' => 'b2bagent',
        'Password' => 'b2bagent',
        'Culture'=>'en-US'
    )
   );
    $client->__setSoapHeaders($header);

   $CountryCode = $_GET['CountryCode'];
   $CityCode = $_GET['CityCode'];
   $CheckIndate = date("Y-m-d", strtotime($_GET['CheckIndate']));
   $CheckoutDate = date("Y-m-d", strtotime($_GET['CheckoutDate']));
   $NoAdult = $_GET['NoAdult'];

   echo "check in date is: " . $CheckIndate;


$params = array(
            'CountryCode' => $CountryCode,
			'CityCode' => $CityCode,
			'CheckIndate' => $CheckIndate,
			'CheckoutDate' => $CheckoutDate,
			'RoomInfo' => array(
							array('NoAdult' => $NoAdult ,'NoChild' => '0', 'ChildAge' => array(0))
							),

			'InstantConfirmationOnly' => 'true'

        );


    //$result = $client->HelloWorld($params);
    $result = $client->SearchHotelsByDestV2($params);
    //var_dump($result);
	//print_r($result);
	//var_dump ($result->SearchHotelsByDestV2Result->any);
	//$var = get_object_vars($result);
	//print_r($var);

	$xml = simplexml_load_string($result->SearchHotelsByDestV2Result->any);
	//var_dump( $xml->AT_HotelList);
	echo "<br /><br />";
	echo "1st Hotel Code = " . $xml->AT_HotelList->Hotel[0]->HotelCode . "<br />";
	echo "1st Hotel Name = " . $xml->AT_HotelList->Hotel[0]->HotelName;

?>



<?php get_header(); ?>

<div class="content-outer-wrapper">

	<div class="row">
		<?php
			foreach ($xml->AT_HotelList->Hotel as $hotel) {
				 echo $hotel->HotelName;
			}
		?>
	</div>

</div> <!-- content outer wrapper -->
<?php get_footer(); ?>

<?php


       $params = array(
                    'CountryCode' => 'SG',
					'CityCode' => 'SIN',
					'CheckIndate' => '2016-03-20',
					'CheckoutDate' => '2016-03-21',
					'RoomInfo' => array(
									array('NoAdult' => '2','NoChild' => '0', 'ChildAge' => array(0))
									),

					'InstantConfirmationOnly' => 'true'

                );




?>